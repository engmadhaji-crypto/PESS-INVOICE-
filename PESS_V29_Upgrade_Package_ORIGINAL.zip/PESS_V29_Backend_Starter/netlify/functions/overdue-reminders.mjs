import { getStore } from '@netlify/blobs';

export const config = { schedule: '0 8 * * *' };

export default async () => {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.REMINDER_FROM;
  if (!apiKey || !from) {
    console.error('Missing RESEND_API_KEY or REMINDER_FROM');
    return new Response('Reminder email configuration missing', { status: 500 });
  }
  const store = getStore('pess-overdue-invoices');
  const listed = await store.list({ prefix: 'invoice:' });
  const today = new Date().toISOString().slice(0, 10);
  let sent = 0, skipped = 0, failed = 0;
  for (const blob of listed.blobs || []) {
    try {
      const invoice = await store.get(blob.key, { type: 'json' });
      if (!invoice || !invoice.invoiceNo || !invoice.dueDate || invoice.dueDate >= today || ['مدفوع', 'ملغي', 'ملغاة'].includes(invoice.status)) { skipped++; continue; }
      if (invoice.reminderSentForDueDate === invoice.dueDate) { skipped++; continue; }
      const amount = `${Number(invoice.total).toLocaleString('en-US', { maximumFractionDigits: 2 })} ${invoice.currency || 'YER'}`;
      const html = `<p>مرحباً ${escapeHtml(invoice.clientName || '')}،</p><p>نود تذكيركم بأن الفاتورة <strong>${escapeHtml(invoice.invoiceNo)}</strong> قد تجاوزت تاريخ الاستحقاق (${escapeHtml(invoice.dueDate)}).</p><p>المبلغ المستحق: <strong>${escapeHtml(amount)}</strong></p><p>يرجى التواصل معنا لترتيب السداد. شكراً لكم.</p>`;
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST', headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ from, to: [invoice.email], subject: `تذكير باستحقاق الفاتورة ${invoice.invoiceNo}`, html })
      });
      if (!response.ok) { failed++; console.error('Email provider error', invoice.invoiceNo, response.status, await response.text()); continue; }
      invoice.reminderSentForDueDate = invoice.dueDate;
      invoice.reminderSentAt = new Date().toISOString();
      await store.setJSON(blob.key, invoice);
      sent++;
    } catch (error) { failed++; console.error('Reminder failure', blob.key, error); }
  }
  return Response.json({ ok: failed === 0, sent, skipped, failed, checkedAt: new Date().toISOString() });
};

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}
