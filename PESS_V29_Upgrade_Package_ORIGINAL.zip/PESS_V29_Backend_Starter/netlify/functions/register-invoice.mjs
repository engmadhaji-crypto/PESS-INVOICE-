import { getStore } from '@netlify/blobs';

export default async (request) => {
  if (request.method !== 'POST') return new Response('Method Not Allowed', { status: 405 });
  const token = process.env.PESS_SYNC_TOKEN;
  if (!token || request.headers.get('authorization') !== `Bearer ${token}`) {
    return new Response('Unauthorized', { status: 401 });
  }
  let doc;
  try { doc = await request.json(); } catch { return Response.json({ error: 'Invalid JSON' }, { status: 400 }); }
  const invoiceNo = String(doc?.invoiceNo || '').trim();
  const dueDate = String(doc?.dueDate || '').trim();
  const email = String(doc?.client?.email || '').trim();
  const total = Number(doc?.grandTotal ?? doc?.totals?.grand);
  const type = String(doc?.docType || doc?.type || 'invoice');
  if (!invoiceNo || !/^\d{4}-\d{2}-\d{2}$/.test(dueDate) || !email || !Number.isFinite(total) || type !== 'invoice') {
    return Response.json({ error: 'Required: invoiceNo, ISO dueDate, client.email, numeric total, invoice docType' }, { status: 400 });
  }
  const store = getStore('pess-overdue-invoices');
  const key = `invoice:${invoiceNo}`;
  const prior = await store.get(key, { type: 'json' });
  const record = {
    invoiceNo, dueDate, email, clientName: String(doc?.client?.name || ''),
    total, currency: String(doc?.currency || 'YER'),
    status: String(doc?.docStatus || ''),
    reminderSentForDueDate: prior?.dueDate === dueDate ? (prior.reminderSentForDueDate || null) : null,
    updatedAt: new Date().toISOString()
  };
  await store.setJSON(key, record);
  return Response.json({ ok: true, invoiceNo });
};
